#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N 5
#define M 3
#include "bingo.h"
#include "get_number_byme.h"
#include "get_number_bycom.h"


int process_bingo(int bingo2[N][N],int number);
